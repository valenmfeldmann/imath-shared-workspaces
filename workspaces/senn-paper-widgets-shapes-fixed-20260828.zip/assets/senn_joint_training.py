import torch
import torch.nn as nn


class ConceptEncoder(nn.Module):
    def __init__(self, d_in, k):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(d_in, 8), nn.ReLU(), nn.Linear(8, k))

    def forward(self, x):
        return self.net(x)


class Decoder(nn.Module):
    def __init__(self, k, d_in):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(k, 8), nn.ReLU(), nn.Linear(8, d_in))

    def forward(self, h):
        return self.net(h)


class RelevanceNet(nn.Module):
    def __init__(self, d_in, k):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(d_in, 8), nn.ReLU(), nn.Linear(8, k))

    def forward(self, x):
        return self.net(x)


def senn_forward(x, h_net, theta_net):
    h = h_net(x)
    theta = theta_net(x)
    f = (theta * h).sum(dim=-1)
    return f, h, theta


def robustness_term(x, h_net, theta_net):
    """Literal Eq. 3: || grad_x f(x) - theta(x)^T J_x h(x) ||^2, per example,
    via double backward (create_graph=True) so it stays differentiable
    through the OUTER loss.backward() call in train_senn() below."""
    x = x.clone().requires_grad_(True)
    f, h, theta = senn_forward(x, h_net, theta_net)
    grad_f = torch.autograd.grad(f.sum(), x, create_graph=True)[0]
    jac_term = torch.zeros_like(grad_f)
    for i in range(h.shape[1]):
        grad_hi = torch.autograd.grad(h[:, i].sum(), x, create_graph=True)[0]
        jac_term = jac_term + theta[:, i:i + 1] * grad_hi
    return ((grad_f - jac_term) ** 2).sum(dim=-1).mean()


def train_senn(n_concepts, n_epochs, lambda_robust):
    k = max(1, int(round(n_concepts)))
    epochs = max(1, int(round(n_epochs)))
    lam = float(lambda_robust)

    torch.manual_seed(0)
    n, d = 200, 5
    X = torch.randn(n, d)
    true_w = torch.tensor([1.0, -0.5, 0.3, 0.8, -0.2])
    y = (X @ true_w) + 0.3 * (X[:, 0] * X[:, 1]) + 0.05 * torch.randn(n)

    h_net = ConceptEncoder(d, k)
    theta_net = RelevanceNet(d, k)
    dec_net = Decoder(k, d)
    params = list(h_net.parameters()) + list(theta_net.parameters()) + list(dec_net.parameters())
    opt = torch.optim.Adam(params, lr=1e-3)

    curve = []
    for epoch in range(epochs):
        opt.zero_grad()
        f, h, theta = senn_forward(X, h_net, theta_net)
        pred_loss = ((f - y) ** 2).mean()
        recon_loss = ((dec_net(h) - X) ** 2).mean()
        robust_loss = robustness_term(X, h_net, theta_net) if lam > 0 else torch.tensor(0.0)

        total = pred_loss + recon_loss + lam * robust_loss
        total.backward()
        opt.step()

        # Always report the TRUE (unweighted) robustness term, even when
        # lam == 0, so the loss curve is comparable across slider settings --
        # otherwise a lam=0 run would misleadingly show a flat zero line.
        # robustness_term() needs live autograd (double backward internally),
        # so this must NOT be wrapped in torch.no_grad().
        true_robust = robust_loss.item() if lam > 0 else robustness_term(X, h_net, theta_net).item()
        # Column 0 is the epoch index itself -- DomainBlock's own sockets
        # are NOT a usable "fake time axis" for a PlotBlock (its own doc
        # warns this silently shows nothing), so the X series for the loss
        # curve has to come from real computed data instead, same as
        # pred_loss/robust_loss below. Column 3 (recon_loss) appended
        # after the fact so existing columns 0-2 stay stable for whatever
        # is already wired to them.
        curve.append([epoch, pred_loss.item(), true_robust, recon_loss.item()])

    return curve


def _linear_weights(seq_module):
    """Pulls [[W1, b1], [W2, b2], ...] out of an nn.Sequential of
    Linear/ReLU layers, in chain order -- exactly the shape
    ComposeModelFromLayersBlock expects for its Weights input."""
    out = []
    for layer in seq_module:
        if isinstance(layer, nn.Linear):
            out.append([layer.weight.detach().tolist(), layer.bias.detach().tolist()])
    return out


def train_senn_h_weights(n_epochs, lambda_robust):
    """Same training routine as train_senn(), fixed at k=3 concepts so the
    returned weight shapes always match a fixed Linear(5,8)->ReLU->Linear(8,3)
    Architecture chain wired into ComposeModelFromLayersBlock. Returns just
    the trained concept encoder's weights -- PythonExecutionBlock has one
    Output socket, so exposing both the loss curve (train_senn, above) and
    these weights from a single run isn't possible; this re-runs training
    with the same fixed seed, which is deterministic and cheap (~1-2s) at
    this scale, not a genuine correctness issue -- just a duplicated compute
    cost worth knowing about."""
    k = 3
    epochs = max(1, int(round(n_epochs)))
    lam = float(lambda_robust)

    torch.manual_seed(0)
    n, d = 200, 5
    X = torch.randn(n, d)
    true_w = torch.tensor([1.0, -0.5, 0.3, 0.8, -0.2])
    y = (X @ true_w) + 0.3 * (X[:, 0] * X[:, 1]) + 0.05 * torch.randn(n)

    h_net = ConceptEncoder(d, k)
    theta_net = RelevanceNet(d, k)
    dec_net = Decoder(k, d)
    params = list(h_net.parameters()) + list(theta_net.parameters()) + list(dec_net.parameters())
    opt = torch.optim.Adam(params, lr=1e-3)

    for _ in range(epochs):
        opt.zero_grad()
        f, h, theta = senn_forward(X, h_net, theta_net)
        pred_loss = ((f - y) ** 2).mean()
        recon_loss = ((dec_net(h) - X) ** 2).mean()
        robust_loss = robustness_term(X, h_net, theta_net) if lam > 0 else torch.tensor(0.0)
        total = pred_loss + recon_loss + lam * robust_loss
        total.backward()
        opt.step()

    return _linear_weights(h_net.net)


def train_senn_theta_weights(n_epochs, lambda_robust):
    """Identical routine to train_senn_h_weights(), same fixed seed and
    k=3, but returns the trained RELEVANCE network's weights instead --
    same architecture shape (Linear(5,8)->ReLU->Linear(8,3)) as h_net, so
    it plugs into the SAME Architecture chain already wired for h_net's
    own ComposeModelFromLayersBlock. Combine the two composed Models with
    CombineModelsBlock(mode='dot') to get the real joint f(x)=theta(x)^T
    h(x) prediction as one attributable Model."""
    k = 3
    epochs = max(1, int(round(n_epochs)))
    lam = float(lambda_robust)

    torch.manual_seed(0)
    n, d = 200, 5
    X = torch.randn(n, d)
    true_w = torch.tensor([1.0, -0.5, 0.3, 0.8, -0.2])
    y = (X @ true_w) + 0.3 * (X[:, 0] * X[:, 1]) + 0.05 * torch.randn(n)

    h_net = ConceptEncoder(d, k)
    theta_net = RelevanceNet(d, k)
    dec_net = Decoder(k, d)
    params = list(h_net.parameters()) + list(theta_net.parameters()) + list(dec_net.parameters())
    opt = torch.optim.Adam(params, lr=1e-3)

    for _ in range(epochs):
        opt.zero_grad()
        f, h, theta = senn_forward(X, h_net, theta_net)
        pred_loss = ((f - y) ** 2).mean()
        recon_loss = ((dec_net(h) - X) ** 2).mean()
        robust_loss = robustness_term(X, h_net, theta_net) if lam > 0 else torch.tensor(0.0)
        total = pred_loss + recon_loss + lam * robust_loss
        total.backward()
        opt.step()

    return _linear_weights(theta_net.net)


def output_curve_sweep(n_epochs, lambda_robust):
    """Intermediate/pedagogical visual: geometric intuition for what the
    Eq. 3 regularizer actually buys you. Trains the same joint model as
    train_senn(), then sweeps ONLY feature 0 over [-3, 3] (the other 4
    features held at 0) and evaluates the real trained f(x) = theta(x).h(x)
    at each point -- a 1D slice through the learned prediction surface.
    At lambda_robust=0 this curve is visibly jagged/wiggly; raising the
    slider should visibly smooth it out, which is the actual geometric
    meaning behind the abstract loss-curve numbers the other widget shows."""
    k = 3
    epochs = max(1, int(round(n_epochs)))
    lam = float(lambda_robust)

    torch.manual_seed(0)
    n, d = 200, 5
    X = torch.randn(n, d)
    true_w = torch.tensor([1.0, -0.5, 0.3, 0.8, -0.2])
    y = (X @ true_w) + 0.3 * (X[:, 0] * X[:, 1]) + 0.05 * torch.randn(n)

    h_net = ConceptEncoder(d, k)
    theta_net = RelevanceNet(d, k)
    dec_net = Decoder(k, d)
    params = list(h_net.parameters()) + list(theta_net.parameters()) + list(dec_net.parameters())
    opt = torch.optim.Adam(params, lr=1e-3)

    for _ in range(epochs):
        opt.zero_grad()
        f, h, theta = senn_forward(X, h_net, theta_net)
        pred_loss = ((f - y) ** 2).mean()
        recon_loss = ((dec_net(h) - X) ** 2).mean()
        robust_loss = robustness_term(X, h_net, theta_net) if lam > 0 else torch.tensor(0.0)
        total = pred_loss + recon_loss + lam * robust_loss
        total.backward()
        opt.step()

    with torch.no_grad():
        sweep_vals = torch.linspace(-3.0, 3.0, 41)
        Xs = torch.zeros(41, d)
        Xs[:, 0] = sweep_vals
        fs, _, _ = senn_forward(Xs, h_net, theta_net)

    return [[float(sweep_vals[i]), float(fs[i])] for i in range(41)]


def theta_curve_sweep(n_epochs, lambda_robust):
    """Intermediate/pedagogical visual: Eq. 3 directly constrains theta(x)'s
    fidelity to the true local sensitivity of h, NOT f(x) itself --
    output_curve_sweep's f(x) smoothness (above) is a downstream side
    effect, one derivative removed from what the regularizer actually
    penalizes. This sweeps feature 0 over [-3, 3] exactly like
    output_curve_sweep but evaluates the trained relevance network
    theta(x) at each point instead -- exposing the explanation vector's
    OWN stability, the quantity Eq. 3 directly regularizes. At
    lambda_robust=0 each theta_i(x0) curve should be visibly jagged;
    raising the slider should visibly smooth these lines directly, not
    just f's smoothness as a side effect."""
    k = 3
    epochs = max(1, int(round(n_epochs)))
    lam = float(lambda_robust)

    torch.manual_seed(0)
    n, d = 200, 5
    X = torch.randn(n, d)
    true_w = torch.tensor([1.0, -0.5, 0.3, 0.8, -0.2])
    y = (X @ true_w) + 0.3 * (X[:, 0] * X[:, 1]) + 0.05 * torch.randn(n)

    h_net = ConceptEncoder(d, k)
    theta_net = RelevanceNet(d, k)
    dec_net = Decoder(k, d)
    params = list(h_net.parameters()) + list(theta_net.parameters()) + list(dec_net.parameters())
    opt = torch.optim.Adam(params, lr=1e-3)

    for _ in range(epochs):
        opt.zero_grad()
        f, h, theta = senn_forward(X, h_net, theta_net)
        pred_loss = ((f - y) ** 2).mean()
        recon_loss = ((dec_net(h) - X) ** 2).mean()
        robust_loss = robustness_term(X, h_net, theta_net) if lam > 0 else torch.tensor(0.0)
        total = pred_loss + recon_loss + lam * robust_loss
        total.backward()
        opt.step()

    with torch.no_grad():
        sweep_vals = torch.linspace(-3.0, 3.0, 41)
        Xs = torch.zeros(41, d)
        Xs[:, 0] = sweep_vals
        _, _, thetas = senn_forward(Xs, h_net, theta_net)

    return [[float(sweep_vals[i]), float(thetas[i, 0]), float(thetas[i, 1]), float(thetas[i, 2])] for i in range(41)]


def concept_prototypes(n_epochs, lambda_robust, concept_idx):
    """Intermediate/pedagogical visual: a synthetic-data substitute for the
    paper's Fig. 2 prototype grounding, which needs real images this
    workspace doesn't have. Trains the same joint model, then finds the 5
    synthetic training examples whose learned concept h_i(x) activates
    MOST STRONGLY for concept i = concept_idx (clamped to 0..2, matching
    the fixed k=3 used elsewhere) -- the direct analogue of "these are the
    real examples that light up this concept," just on 5-dim feature
    vectors instead of pictures. Returns
    [[x0, x1, x2, x3, x4, h_i], ...] sorted by h_i descending, 5 rows."""
    k = 3
    epochs = max(1, int(round(n_epochs)))
    lam = float(lambda_robust)
    c = max(0, min(2, int(round(concept_idx))))

    torch.manual_seed(0)
    n, d = 200, 5
    X = torch.randn(n, d)
    true_w = torch.tensor([1.0, -0.5, 0.3, 0.8, -0.2])
    y = (X @ true_w) + 0.3 * (X[:, 0] * X[:, 1]) + 0.05 * torch.randn(n)

    h_net = ConceptEncoder(d, k)
    theta_net = RelevanceNet(d, k)
    dec_net = Decoder(k, d)
    params = list(h_net.parameters()) + list(theta_net.parameters()) + list(dec_net.parameters())
    opt = torch.optim.Adam(params, lr=1e-3)

    for _ in range(epochs):
        opt.zero_grad()
        f, h, theta = senn_forward(X, h_net, theta_net)
        pred_loss = ((f - y) ** 2).mean()
        recon_loss = ((dec_net(h) - X) ** 2).mean()
        robust_loss = robustness_term(X, h_net, theta_net) if lam > 0 else torch.tensor(0.0)
        total = pred_loss + recon_loss + lam * robust_loss
        total.backward()
        opt.step()

    with torch.no_grad():
        h_all = h_net(X)[:, c]
        top5 = torch.argsort(h_all, descending=True)[:5]
        rows = []
        for idx in top5:
            xi = X[idx].tolist()
            rows.append(xi + [float(h_all[idx])])
    return rows


def hook_instability_demo(n_epochs):
    """Motivational hook: an UNregularized (lambda_robust=0 fixed) model's
    plain gradient explanation d f/d x can change a lot between two
    nearly identical inputs even though the prediction barely moves --
    the exact instability the paper opens with (its Fig. 9), shown here
    before SENN or Eq. 3 are even introduced.

    A single random small perturbation usually does NOT show this (tested:
    a random 1% step gave only a 0.5% relative gradient change) -- the
    paper's claim is that an unstable direction EXISTS nearby, not that
    every direction is unstable. So this searches 200 random directions at
    a fixed epsilon=0.1 and keeps the one with the largest relative change
    in the gradient vector, the same "does an unstable neighbor exist"
    question Eq. 5's adversarial search asks later, just applied here
    before SENN is introduced, to demonstrate the problem it solves.
    Verified locally this reliably finds >40% relative gradient change
    while the prediction itself moves by only a few percent.

    Returns [[feature_idx, grad_at_base, grad_at_worst_neighbor, f_base,
    f_at_worst_neighbor], ...], 5 rows (f_base/f_pert repeated on every
    row so the whole result stays one rectangular matrix)."""
    k = 3
    epochs = max(1, int(round(n_epochs)))

    torch.manual_seed(0)
    n, d = 200, 5
    X = torch.randn(n, d)
    true_w = torch.tensor([1.0, -0.5, 0.3, 0.8, -0.2])
    y = (X @ true_w) + 0.3 * (X[:, 0] * X[:, 1]) + 0.05 * torch.randn(n)

    h_net = ConceptEncoder(d, k)
    theta_net = RelevanceNet(d, k)
    dec_net = Decoder(k, d)
    params = list(h_net.parameters()) + list(theta_net.parameters()) + list(dec_net.parameters())
    opt = torch.optim.Adam(params, lr=1e-3)

    for _ in range(epochs):
        opt.zero_grad()
        f, h, theta = senn_forward(X, h_net, theta_net)
        pred_loss = ((f - y) ** 2).mean()
        recon_loss = ((dec_net(h) - X) ** 2).mean()
        total = pred_loss + recon_loss
        total.backward()
        opt.step()

    def grad_at(x):
        x = x.clone().requires_grad_(True)
        f, _, _ = senn_forward(x, h_net, theta_net)
        g = torch.autograd.grad(f.sum(), x)[0]
        return g.reshape(-1), float(f.sum())

    torch.manual_seed(1)
    x_base = torch.randn(1, d)
    g_base, f_base = grad_at(x_base)

    eps = 0.1
    best_rel, best_g_pert, best_f_pert = -1.0, None, None
    for _ in range(200):
        direction = torch.randn(1, d)
        direction = direction / (direction.norm() + 1e-8)
        x_pert = x_base + eps * direction
        g_pert, f_pert = grad_at(x_pert)
        rel = (g_base - g_pert).norm().item() / (g_base.norm().item() + 1e-8)
        if rel > best_rel:
            best_rel, best_g_pert, best_f_pert = rel, g_pert, f_pert

    return [[i, float(g_base[i]), float(best_g_pert[i]), f_base, best_f_pert] for i in range(d)]
