import numpy as np


def _forward(x, W1, b1, W2, b2):
    z1 = x @ W1.T + b1
    a1 = np.maximum(z1, 0.0)
    z2 = a1 @ W2.T + b2
    return z2


def _forward_grad(x, W1, b1, W2, b2):
    """Gradient of forward(x).sum() wrt x, by hand through the same 2-layer
    ReLU net used elsewhere in this workspace (lrp.py, exact_shap.py) --
    avoids needing autograd for this hand-rolled PGD loop."""
    z1 = x @ W1.T + b1
    grad_a1 = W2.sum(axis=0)  # d(sum(z2))/d(a1), (hidden,)
    grad_z1 = grad_a1 * (z1 > 0).astype(float)  # ReLU derivative
    grad_x = grad_z1 @ W1  # (in,)
    return grad_x


def adversarial_trajectory(W1, b1, W2, b2, x, epsilon):
    """Intermediate/pedagogical visual: the native AdversarialSearchBlock
    (real PGD) only exposes the FINAL worst-case point x_adv, not how the
    search got there. This hand-rolls the identical L-infinity-projected
    gradient ascent on the SAME real trained weights (same convention as
    exact_shap.py/lrp.py: real W1/b1/W2/b2 pulled via
    LayerWeightExtractorBlock), fixed at step_size=0.03, num_steps=15 to
    match the existing AdversarialSearchBlock instance's own defaults, and
    returns one row per iteration: [step, L2 distance from the start
    point, model(x).sum() at that iterate] -- so the search PATH itself
    becomes plottable, not just its endpoint."""
    x0 = np.asarray(x, dtype=float).reshape(-1)
    W1 = np.asarray(W1, dtype=float)
    b1 = np.asarray(b1, dtype=float).reshape(-1)
    W2 = np.asarray(W2, dtype=float)
    b2 = np.asarray(b2, dtype=float).reshape(-1)
    eps = float(epsilon)
    step = 0.03
    num_steps = 15

    xk = x0.copy()
    rows = [[0, 0.0, float(_forward(xk, W1, b1, W2, b2).sum())]]
    for k in range(1, num_steps + 1):
        grad = _forward_grad(xk, W1, b1, W2, b2)
        xk = xk + step * np.sign(grad)
        xk = np.clip(xk, x0 - eps, x0 + eps)
        dist = float(np.linalg.norm(xk - x0))
        val = float(_forward(xk, W1, b1, W2, b2).sum())
        rows.append([k, dist, val])
    return rows


if __name__ == "__main__":
    rng = np.random.default_rng(0)
    W1 = rng.normal(size=(6, 5))
    b1 = rng.normal(size=(6,))
    W2 = rng.normal(size=(5, 6))
    b2 = rng.normal(size=(5,))
    x = np.array([0.2, -0.5, 0.1, 0.4, -0.3])
    out = adversarial_trajectory(W1, b1, W2, b2, x, 0.15)
    for row in out:
        print(row)
    # sanity: distance should be non-decreasing and saturate near epsilon
    dists = [r[1] for r in out]
    assert all(dists[i] <= dists[i + 1] + 1e-9 for i in range(len(dists) - 1)), "distance should grow monotonically under fixed-sign steps until clamped"
    assert max(dists) <= 0.15 * np.sqrt(5) + 1e-9, "L2 distance should stay within the L-inf ball's diagonal bound"
    print("sanity checks passed")
