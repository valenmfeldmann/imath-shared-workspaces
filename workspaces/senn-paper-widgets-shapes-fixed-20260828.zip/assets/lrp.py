import numpy as np


def lrp_relevance(W1, b1, W2, b2, x):
    eps = 1e-6
    x = np.asarray(x, dtype=float).reshape(-1)
    W1 = np.asarray(W1, dtype=float)
    b1 = np.asarray(b1, dtype=float).reshape(-1)
    W2 = np.asarray(W2, dtype=float)
    b2 = np.asarray(b2, dtype=float).reshape(-1)

    z1 = x @ W1.T + b1
    a1 = np.maximum(z1, 0.0)
    z2 = a1 @ W2.T + b2

    # Start relevance at the summed output, matching the same "output.sum()"
    # convention this workspace's other real methods use (AdversarialSearch,
    # IntegratedGradients) -- one relevance unit per output neuron, equal to
    # that neuron's own pre-activation value.
    R2 = z2.copy()

    def stabilize(z):
        return z + eps * np.where(z >= 0, 1.0, -1.0)

    # Layer 2 backward: relevance of a1 (post-ReLU, layer-1 output) from R2.
    contrib2 = a1[:, None] * W2.T  # (in=6, out=5)
    denom2 = stabilize(z2)  # (5,)
    R_a1 = (contrib2 / denom2[None, :]) @ R2  # (6,)

    # ReLU passes relevance straight through; a1_i == 0 already zeroes its
    # own column in contrib2 above, so no extra masking is needed here.
    R_z1 = R_a1

    # Layer 1 backward: relevance of x from R_z1.
    contrib1 = x[:, None] * W1.T  # (in=5, out=6)
    denom1 = stabilize(z1)  # (6,)
    R_x = (contrib1 / denom1[None, :]) @ R_z1  # (5,)

    return R_x.reshape(1, -1)


def lrp_hidden_relevance(W1, b1, W2, b2, x):
    """Intermediate/pedagogical visual: LRP's relevance conservation means
    relevance flows through EVERY layer, not just the final input-layer
    scores lrp_relevance() returns. This exposes R_a1 -- the relevance
    already assigned to each of the 6 hidden units after the layer-2
    backward pass, one step before it gets pushed further back to the
    5 input features. Same math as lrp_relevance(), just stopped one
    layer earlier."""
    eps = 1e-6
    x = np.asarray(x, dtype=float).reshape(-1)
    W1 = np.asarray(W1, dtype=float)
    b1 = np.asarray(b1, dtype=float).reshape(-1)
    W2 = np.asarray(W2, dtype=float)
    b2 = np.asarray(b2, dtype=float).reshape(-1)

    z1 = x @ W1.T + b1
    a1 = np.maximum(z1, 0.0)
    z2 = a1 @ W2.T + b2
    R2 = z2.copy()

    def stabilize(z):
        return z + eps * np.where(z >= 0, 1.0, -1.0)

    contrib2 = a1[:, None] * W2.T
    denom2 = stabilize(z2)
    R_a1 = (contrib2 / denom2[None, :]) @ R2

    return R_a1.reshape(1, -1)
