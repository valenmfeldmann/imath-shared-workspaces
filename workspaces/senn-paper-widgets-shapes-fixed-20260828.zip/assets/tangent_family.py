import numpy as np


def tangent_family(domain_halfwidth):
    """Intermediate/pedagogical visual: SENN is 'locally linear, globally
    nonlinear' -- theta(x) is a different local slope at every x. The
    existing local-linearity demo shows exactly ONE tangent line at ONE
    point, which only demonstrates the local-linear half of that claim.
    This overlays 5 tangent lines to f(x) = x^3 - 2x at evenly spaced
    x0 values, all at once, so the ENVELOPE of local linear
    approximations is visible directly -- the direct analogue of showing
    a flow/vector field instead of a single parametric path trace.
    domain_halfwidth controls both the x0 spread and the plotted x-range
    together, so the output shape (fixed at 7 columns: shared x-grid,
    f(x), 5 tangent lines) never changes regardless of slider value --
    required for stable wiring into fixed ExtractColumnBlock sockets."""
    hw = max(0.5, float(domain_halfwidth))
    x0s = np.linspace(-hw, hw, 5)
    xg = np.linspace(-hw - 0.5, hw + 0.5, 61)
    fx = xg ** 3 - 2 * xg

    rows = []
    for i in range(len(xg)):
        row = [float(xg[i]), float(fx[i])]
        for x0 in x0s:
            f_x0 = x0 ** 3 - 2 * x0
            fp_x0 = 3 * x0 ** 2 - 2
            row.append(float(fp_x0 * (xg[i] - x0) + f_x0))
        rows.append(row)
    return rows


if __name__ == "__main__":
    out = tangent_family(2.0)
    print("rows:", len(out), "cols:", len(out[0]))
    print(out[0])
    print(out[30])
    print(out[-1])
