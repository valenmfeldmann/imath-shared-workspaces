import itertools
import numpy as np


def _forward(x, W1, b1, W2, b2):
    z1 = x @ W1.T + b1
    a1 = np.maximum(z1, 0.0)
    z2 = a1 @ W2.T + b2
    return z2


def exact_shap(W1, b1, W2, b2, x):
    x = np.asarray(x, dtype=float).reshape(-1)
    W1 = np.asarray(W1, dtype=float)
    b1 = np.asarray(b1, dtype=float).reshape(-1)
    W2 = np.asarray(W2, dtype=float)
    b2 = np.asarray(b2, dtype=float).reshape(-1)
    n = x.shape[0]
    baseline = np.zeros_like(x)

    def value(subset_mask):
        v = np.where(subset_mask, x, baseline)
        return float(_forward(v, W1, b1, W2, b2).sum())

    features = list(range(n))
    shap = np.zeros(n)
    fact = [1] * (n + 1)
    for i in range(1, n + 1):
        fact[i] = fact[i - 1] * i

    for i in features:
        others = [f for f in features if f != i]
        for r in range(len(others) + 1):
            for subset in itertools.combinations(others, r):
                mask_without = np.zeros(n, dtype=bool)
                for f in subset:
                    mask_without[f] = True
                mask_with = mask_without.copy()
                mask_with[i] = True

                weight = fact[r] * fact[n - r - 1] / fact[n]
                marginal = value(mask_with) - value(mask_without)
                shap[i] += weight * marginal

    return shap.reshape(1, -1)


def exact_shap_coalitions(W1, b1, W2, b2, x):
    """Intermediate/pedagogical visual: exposes the raw v(S) value SHAP
    actually averages over, for all 2^n feature coalitions -- what
    exact_shap() computes internally but never surfaces. Row i corresponds
    to coalition mask i (bit j set means feature j is "present", using x's
    real value; bits unset fall back to the zero baseline), 0..2^n - 1.
    Column 0 is the coalition index itself (so it can double as an X axis
    for a plot), column 1 is v(S) = model(x_S).sum()."""
    x = np.asarray(x, dtype=float).reshape(-1)
    W1 = np.asarray(W1, dtype=float)
    b1 = np.asarray(b1, dtype=float).reshape(-1)
    W2 = np.asarray(W2, dtype=float)
    b2 = np.asarray(b2, dtype=float).reshape(-1)
    n = x.shape[0]
    baseline = np.zeros_like(x)

    rows = []
    for mask_int in range(2 ** n):
        mask = np.array([(mask_int >> j) & 1 for j in range(n)], dtype=bool)
        v = np.where(mask, x, baseline)
        value = float(_forward(v, W1, b1, W2, b2).sum())
        rows.append([mask_int, value])
    return rows
